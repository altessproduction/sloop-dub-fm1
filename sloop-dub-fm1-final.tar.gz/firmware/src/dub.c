/* SPDX-License-Identifier: GPL-3.0-only
 * First playable reggae / dub modules for SLOOP on M-VAVE FM-1.
 */
#include <stdint.h>
#include "dub.h"

#ifndef FS
#define FS 44100u
#endif

#define DUB_Q15 32767
#define DUB_PI2 0x6487ED51u

static int32_t dub_clamp(int32_t x, int32_t lo, int32_t hi)
{
    return x < lo ? lo : x > hi ? hi : x;
}

static int32_t dub_mul15(int32_t a, int32_t b)
{
    return (int32_t)(((int64_t)a * b) >> 15);
}

static int32_t dub_sine(uint32_t phase)
{
    uint32_t q = phase >> 30;
    uint32_t x = (phase >> 15) & 0x7FFFu;
    int32_t y = (int32_t)x;
    if (q & 1u)
        y = 32767 - y;
    if (q & 2u)
        y = -y;
    return y << 1;
}

static uint32_t dub_hz_inc(uint32_t hz)
{
    return (uint32_t)(((uint64_t)hz << 32) / FS);
}

void dub_isolator_init(dub_isolator_t *d)
{
    static const int32_t xo[3] = {90, 420, 2600};
    static const int16_t cuts[4] = {90, 180, 1000, 4200};
    uint32_t i;
    d->enabled = 0;
    d->mix = 127;
    for (i = 0; i < 3; i++)
        d->xover[i] = xo[i];
    for (i = 0; i < DUB_BANDS; i++) {
        d->p[i].cutoff_hz = cuts[i];
        d->p[i].gain_db = 0;
        d->p[i].eq_freq = 64;
        d->p[i].eq_q = 64;
        d->p[i].eq_db = 0;
        d->p[i].mute = 0;
        d->eq_fast[i] = d->eq_slow[i] = 0;
        d->lp[i] = 0;
    }
}

void dub_isolator_set_band(dub_isolator_t *d, uint32_t band, dub_band_param_t p)
{
    if (band >= DUB_BANDS)
        return;
    d->p[band] = p;
    d->p[band].gain_db = (int8_t)dub_clamp(d->p[band].gain_db, -24, 12);
    d->p[band].eq_db = (int8_t)dub_clamp(d->p[band].eq_db, -12, 12);
    d->p[band].eq_q = (uint8_t)dub_clamp(d->p[band].eq_q, 1, 127);
}

static int32_t dub_gain(int8_t db)
{
    int32_t g = 32767;
    int32_t i;
    if (db > 0)
        for (i = 0; i < db; i++)
            g = (g * 36700) >> 15;
    else
        for (i = 0; i > db; i--)
            g = (g * 29200) >> 15;
    return g;
}

static int32_t dub_lowpass(int32_t x, int32_t *state, int32_t hz)
{
    int32_t a = dub_clamp((hz * 2100) / (int32_t)FS, 1, 32700);
    *state += dub_mul15(x - *state, a);
    return *state;
}

void dub_isolator_process(dub_isolator_t *d, int32_t *left, int32_t *right, uint32_t n)
{
    uint32_t i;
    if (!d->enabled || !d->mix)
        return;
    for (i = 0; i < n; i++) {
        int32_t in_l = left[i], in_r = right[i];
        int32_t mono = (in_l + in_r) >> 1;
        int32_t low = dub_lowpass(mono, &d->lp[DUB_SUB], d->xover[0]);
        int32_t low_mid = dub_lowpass(mono - low, &d->lp[DUB_BASS], d->xover[1]);
        int32_t mid = dub_lowpass(mono - low - low_mid, &d->lp[DUB_MIDS], d->xover[2]);
        int32_t bands[DUB_BANDS];
        int32_t wet_l = 0, wet_r = 0;
        uint32_t b;
        bands[DUB_SUB] = low;
        bands[DUB_BASS] = low_mid;
        bands[DUB_MIDS] = mid;
        bands[DUB_TOPS] = mono - low - low_mid - mid;
        for (b = 0; b < DUB_BANDS; b++) {
            int32_t eq = bands[b];
            int32_t q = d->p[b].eq_q + 1;
            eq += (bands[b] - d->eq_fast[b]) * d->p[b].eq_db / 24;
            d->eq_fast[b] += (eq - d->eq_fast[b]) / q;
            d->eq_slow[b] += (d->eq_fast[b] - d->eq_slow[b]) >> 4;
            if (!d->p[b].mute)
                wet_l += dub_mul15(d->eq_slow[b], dub_gain(d->p[b].gain_db));
        }
        wet_r = wet_l;
        left[i] = in_l + ((wet_l - in_l) * d->mix >> 7);
        right[i] = in_r + ((wet_r - in_r) * d->mix >> 7);
    }
}

void dub_siren_init(dub_siren_t *s)
{
    s->phase = 0;
    s->lfo_phase = 0;
    s->phase_inc = dub_hz_inc(740);
    s->lfo_inc = dub_hz_inc(2);
    s->level = 0;
    s->depth = 96;
    s->active = 0;
}

void dub_siren_trigger(dub_siren_t *s, uint8_t level)
{
    s->level = level > 127 ? 127 : level;
    s->active = s->level != 0;
}

void dub_siren_render(dub_siren_t *s, int32_t *left, int32_t *right, uint32_t n)
{
    uint32_t i;
    if (!s->active)
        return;
    for (i = 0; i < n; i++) {
        int32_t lfo = (dub_sine(s->lfo_phase) + 32767) >> 1;
        int32_t amp = s->level * (64 + ((lfo * s->depth) >> 15));
        int32_t y = (dub_sine(s->phase) * amp) >> 14;
        left[i] += y;
        right[i] += y;
        s->phase += s->phase_inc + (uint32_t)((lfo * dub_hz_inc(500)) >> 15);
        s->lfo_phase += s->lfo_inc;
    }
}

void dub_seq_init(dub_seq_t *s)
{
    uint32_t i;
    s->length = 16;
    s->step = 0;
    for (i = 0; i < 64; i++) {
        s->notes[i] = 0;
        s->velocity[i] = 0;
    }
}

void dub_seq_set_length(dub_seq_t *s, uint8_t length)
{
    if (length == 16 || length == 32 || length == 64)
        s->length = length;
}

void dub_seq_set_step(dub_seq_t *s, uint8_t step, uint8_t note, uint8_t velocity)
{
    if (step >= 64)
        return;
    s->notes[step] = note;
    s->velocity[step] = velocity;
}

void dub_seq_advance(dub_seq_t *s)
{
    s->step++;
    if (s->step >= s->length)
        s->step = 0;
}

uint8_t dub_skank_build(const dub_skank_t *s, uint8_t key, uint8_t *notes, uint8_t max_notes)
{
    static const uint8_t triad[4][3] = {{0, 4, 7}, {0, 3, 7}, {0, 3, 6}, {0, 4, 8}};
    uint8_t q = s->quality & 3u;
    uint8_t root = (uint8_t)(s->root + key + 12u * s->octave);
    uint8_t i, count = max_notes < 3 ? max_notes : 3;
    for (i = 0; i < count; i++)
        notes[i] = (uint8_t)(root + triad[q][i]);
    return count;
}

const dub_preset_t DUB_PRESETS[] = {
    {"ROOTS BASS", 1, 0, 0, -12, 8, 36, 18, 0},
    {"SKANK CHORD", 2, 2, -4, 8, 22, 28, 42, 1},
    {"DUB SIREN", 3, 1, -8, 22, 12, 54, 38, 0},
    {"STEPPERS", 4, 3, -2, -4, 16, 18, 28, 0},
    {"TAPE ECHO", 5, 0, -6, 4, 10, 82, 66, 0}
};
const uint32_t DUB_PRESET_COUNT = sizeof DUB_PRESETS / sizeof DUB_PRESETS[0];

dub_isolator_t dub_isolator;
dub_siren_t dub_siren;
dub_seq_t dub_sequence;
uint8_t dub_enabled = 0;
